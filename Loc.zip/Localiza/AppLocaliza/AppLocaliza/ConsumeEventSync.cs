﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace AppLocaliza
{
    public class ConsumeEventSync
    {

        public void GetAllEventData(int numero) //Get All Events Records  
        {
            try
            {
                using (var client = new WebClient()) //WebClient  
                {
                    client.Headers.Add("Content-Type:application/json"); //Content-Type  
                    client.Headers.Add("Accept:application/json");
                    
                    var result = client.DownloadString("https://localhost:44366/localizanumeros/" + numero); //URI  

                    Console.WriteLine(Environment.NewLine + result);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
           
        }
    }
}
