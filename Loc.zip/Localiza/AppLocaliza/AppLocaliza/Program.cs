﻿using System;
using System.Collections.Generic;
using System.Net;

namespace AppLocaliza
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declaração de variáveis 
            int numero;
            List<int> divisores = new List<int>();
            List<int> primos = new List<int>();

            try
            {
                //Solicita que o usuário informe um número
                Console.WriteLine("Informe um número e tecle ENTER: ");

                //Realiza a leitura do núemro;         
                numero = Convert.ToInt32(Console.ReadLine());

                for (int i = 1; i < numero; i++)
                {
                    //Verifica se é divisor 
                    if (numero % i == 0)
                    {
                        divisores.Add(i);

                        //Verifica se é número primo
                        if (VerificarNumeroPrimo(i))
                            primos.Add(i);
                    }
                }

                //Todo número e divisor dele mesmo
                divisores.Add(numero);

                Console.Write("Números divisores: ");
                divisores.ForEach(i => Console.Write("{0}\t", i));

                Console.WriteLine(" ");

                Console.Write("Divisores Primos: ");
                primos.ForEach(i => Console.Write("{0}\t", i));

                //Consome API o mesmo para funcionar deve esta no modo start.
                ConsumeEventSync objSync = new ConsumeEventSync();
                objSync.GetAllEventData(numero);

                Console.ReadKey();
            }
            catch (Exception ex)
            {
                throw ex;
            }            		
		}

        public static bool VerificarNumeroPrimo(int num)
        {
            try
            {
                for (int i = 2; i < num; i++)
                    if (num % i == 0)
                        return false;

                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }           
        } 
    }
}
