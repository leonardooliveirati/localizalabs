﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ApiLocaliza
{
    public class Numbers
    {
        public int primos { get; set; }

        public int divisores { get; set; }

    }
}
